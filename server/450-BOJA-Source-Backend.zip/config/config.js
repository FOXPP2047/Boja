module.exports = {
    connectionLimit : 10,
    password : "bojapassowrd12",
    user : "root",
    database : "bojaDB",
    host : 'localhost',
    port : '3306'
}